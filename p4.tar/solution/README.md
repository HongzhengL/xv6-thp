# COMP SCI 537 Project 4

-   name: Hongzheng Li, Junjie Yan
-   CS Login: hongzheng, jyan
-   Wisc ID: hli2225, jyan244
-   Email: <hongzheng@cs.wisc.edu>
-   Status of Implementation: All tests passed
-   Names of all the files changed in `solution/`:
    -   **main.c**: Init huge page when boot up
    -   **kalloc.c**: `khugeinit`, `freehugerange`, `khugefree`, `khugealloc`
    -   **user.h**: Added function prototypes for `vmalloc`, `vfree`, `setthp(int)` and `checkthp(void)` to enable and check transparent huge page usage.
    -   **sysproc.c**: Refactored indentation and introduced the system call handlers `sys_setthp()` and `sys_checkthp()` for transparent huge pages.
    -   **defs.h**: Declared the new functions `setthp(int)` and `checkthp(void)` to manage transparent huge pages.
    -   **proc.c**: Added a global variable `thp_enabled` and implemented `setthp()` and `checkthp()` to control and query huge page behavior.
    -   **vm.c**: Enhanced page-mapping routines to support both base and huge page allocations, along with indentation cleanups.
    -   **umalloc.c**: Implemented logic to automatically allocate/fallback to huge pages (based on `thp_enabled`) and introduced `vfree()` for freeing huge-page allocations.
    -   **syscall.h**: Reserved new system call numbers for `setthp` and `checkthp`.
    -   **syscall.c**: Hooked the newly added `setthp` and `checkthp` system calls into the syscall dispatch mechanism.
    -   **usys.S**: Generated user-space stubs for the `setthp` and `checkthp` system calls.
    -   **`ALL C FILES`**: Format all `.h` and `.c` files using `.clang-format` with `Google Style`
